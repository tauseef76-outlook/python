movies = []  # list to store movies


def menu():  # menu function
    user_input = input("Enter 'a' to add a movie, 'l' to see your movie, 'f' to find a movie, and 'q' to quit: ")

    while user_input != 'q':
        if user_input == 'a':
            add_movie()

        elif user_input == 'l':
            show_movies(movies)

        elif user_input == 'f':
            find_movie()

        else:
            print("Unknown command....")

        user_input = input("\nEnter 'a' to add a movie, 'l' to see your movie, 'f' to find a movie, and 'q' to quit: ")


def add_movie():
    name = input("Enter movie name: ")
    director = input("Enter movie director: ")
    year = int(input("Enter movie year: "))

    movies.append({
        'name': name,
        'director': director,
        'year': year
    })


def show_movies(movie_list):
    for movie in movie_list:
        print(f"Name: {movie['name']}")
        print(f"Director: {movie['director']}")
        print(f"Release year: {movie['year']}")


def find_movie():
    find_by = input("What property of the movie are you looking for? ")
    looking_for = input("What are you searching for? ")

    found = []

    for movie in movies:
        if movie[find_by] == looking_for:
            found.append(movie)

    show_movies(found)


menu()
