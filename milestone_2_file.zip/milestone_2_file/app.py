import utils.database

USER_IN= """Enter:
- 'a' to add new book.
- 'l' to list books.
- 'd' to delete a book.
- 'q' to quit
"""

def menu():

    USER_CHOICE = input(USER_IN)

    while USER_CHOICE != 'q':

        if USER_CHOICE == 'a':
            prompt_add_book()

        elif USER_CHOICE == 'l':
            list_books()

        elif USER_CHOICE == 'd':
            prompt_delete_book()

        else:
            print("Please enter correct command...")

        print('\n')
        USER_CHOICE = input(USER_IN)


def prompt_add_book():
    name = input("Enter book name: ")
    author = input("Enter author name: ")

    utils.database.add_book(name, author)


def list_books():
    books = utils.database.get_all_books()
    for book in books:
        print(f"{book['name']} by {book['author']}")


def prompt_delete_book():
    name = input("Enter book name to delete: ")

    utils.database.delete_book(name)


menu()
